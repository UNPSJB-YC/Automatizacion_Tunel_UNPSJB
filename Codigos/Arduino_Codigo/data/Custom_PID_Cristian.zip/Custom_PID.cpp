/*
 * Code File 
 */ 
#include "Arduino.h"
#include "Custom_PID.h"
 
PID::PID(float tempP, float tempI, float tempD) {
    kP = tempP; 
    kI = tempI; 
    kD = tempD; 
   } 
 
bool PID::Initialize() {
    currTime = millis(); 
    prevTime = currTime; 
 
    prevError = 0; 
     
    cP = 0; 
    cI = 0; 
    cD = 0; 
 
    return true; 
}
 
float PID::Update(float tempError, int tempDelay) {
  //delay(tempDelay); 
	
  		
  currTime = millis(); 
  deltaTime = currTime - prevTime; 
 
  deltaError = tempError - prevError; 
 
  cP = tempError; 
  
  
  cI += tempError*deltaTime/1000;
 
  if (deltaTime > 0) {
    cD = (deltaError/deltaTime); 
   } else {
    cD = 0; 
   } 
 
  prevTime = currTime; 
  prevError = tempError; 
 
  if (kI*cI>1023){
  cI=(1023/kI);
  }
  if (kI*cI<-1023){
  cI=(-1023/kI);
  }
  output=((kP*cP) + (kI*cI) + (kD*cD));
  output=constrain(output,0,1023);
  return output; 
}